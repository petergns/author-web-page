Requirements:
After setup your drupal 8 site. Download and enable(Don't set as default) this 
base theme https://www.drupal.org/project/mbase. 

After install "mbase" theme, install the generated theme. You can change the
Home page content in theme settings page. 


Help site is coming soon : help.cmsbots.com
You can hire us for premium support adal [at] cmsbots.com or for any other inquiry
  
  
Color Scheams are from there 
https://material.google.com/style/color.html#color-color-palette
